class Bodega:
    def __init__(self):
        self.Motos =list[Moto]= [] 
    
    def agregar_moto(self, moto):
        #marca:str =  input("Ingrese la marca: ")
        #cilindraje = int(input("Ingrese el CC: "))
        #modelo:str = input("Ingrese modelo: ")
        #precio:str =  input("Ingrese precio: ")
        #moto = Moto(marca,cilindraje,modelo,precio)
        #self.Motos.append(moto.id)
        pass

    def mostrar_motos(self):
        pass

    def mostrar_motos_marca(self, marca):
        pass

    def eliminar_moto(self):
        pass

class Moto:
    id = 99
    def __init__(self, marca:str, cilindraje:int, modelo:str, color:str, precio):
        self.marca = marca
        self.cilindraje = cilindraje
        self.modelo = modelo
        self.color = color
        self.__precio = precio
        self.__class__.id += 1

    @property
    def precio(self):
        return self.__precio
    
    def __str__(self) -> str:
        string = f"Marca:  {self.marca}\nCC:     {self.cilindraje}\nModelo: {self.modelo}\nColor:  {self.color}\nPrecio: {self.__precio}"
        return string


moto1 = Moto("BMW",750,2000,"Negro",2000000)
print(moto1)

