class Empleado:
    ide = 299

    def __init__(self, cedula, nombre, apellido, MotosVendidas):
        self.cedula = cedula
        self.nombre = nombre
        self.apellido = apellido
        self.MotosVendidas = MotosVendidas
        self.__class__.ide += 1
    
    def agregar_vendedor(self):
        pass

    def mostrar_vendedores(self):
        pass
