class Cliente:
    idc = 199
    def __init__(self,cedula,nombre,apellido,cantidad_compras):
        self.cedula = cedula
        self.nombre = nombre
        self.apellido = apellido
        self.cantidad_compras = cantidad_compras
        self.__class__.idc += 1

    def agregar_cliente(self):
        pass

    def agregar_cl_interesado(self):
        pass
    
    def mostrar_clientes(self):
        pass
    def mostrar_cl_cedula(self):
        pass

    def mostrar_clientesInt(self):
        pass
    